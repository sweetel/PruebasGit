package com.pablo.ludoteca.entidades;

public class Ninho extends Persona {

	private Boolean tieneDiscapacidad;
	private Curso tipoCurso;
	
	public Ninho(String nombre, Integer edad, char sexo, Boolean tieneDiscapacidad) {
		super(nombre, edad, sexo);
		this.tieneDiscapacidad = tieneDiscapacidad;
	}

	public Boolean getTieneDiscapacidad() {
		return tieneDiscapacidad;
	}

	public void setTieneDiscapacidad(Boolean tieneDiscapacidad) {
		this.tieneDiscapacidad = tieneDiscapacidad;
	}

	public Curso getTipoCurso() {
		return tipoCurso;
	}

	public void setTipoCurso(Curso tipoCurso) {
		this.tipoCurso = tipoCurso;
	}
	
	
}
