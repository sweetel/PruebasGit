package com.pablo.ludoteca.interfaces;

import java.util.Scanner;

import com.pablo.ludoteca.entidades.Curso;
import com.pablo.ludoteca.entidades.Ninho;
import com.pablo.ludoteca.entidades.Progenitor;

public class MenuPrincipal {

	public void mostrarMenu() {

		Progenitor progenitor1 = null;
		Ninho ninho1 = null;
		Curso curso1 = null;
		Scanner sc = new Scanner(System.in);
		int opcion;

		do {

			System.out.println("***** LUDOTECA AYUNTAMIENDO DE SALAMANCA *****");
			System.out.println("Teclee la opcion a realizar: ");
			System.out.println("1. Dar de alta a progenitor");
			System.out.println("2. Dar de alta a niño");
			System.out.println("3. Apuntar niño al curso");
			System.out.println("4. Emitir recibo");
			System.out.println("5. Salir");
			opcion = sc.nextInt();
			sc.nextLine();

			switch (opcion) {

			case 1:
				MenuAltaProgenitor mp = new MenuAltaProgenitor();
				progenitor1 = mp.mostrarMenu(sc);
				break;

			case 2:
				if(progenitor1 == null) {
					System.out.println("ERROR introduce un progenitor");
				} else {
				MenuAltaNinho mn = new MenuAltaNinho();
				ninho1 = mn.mostrarMenu(sc);
				progenitor1.setTipoNinho(ninho1);
				System.out.println("El niño con nombre " + ninho1.getNombre() + " ha sido asignado al progenitor " + progenitor1.getNombre());
				}
				break;
			case 3: 
				if(ninho1 == null) {
					System.out.println("ERROR da de alta un niño");
				} else {
				MenuAltaCurso mc = new MenuAltaCurso();
				curso1 = mc.mostarMenu(sc);
				ninho1.setTipoCurso(curso1);
				System.out.println("El niño: " + ninho1.getNombre() + " ha sido dado de alta en el curso: " + curso1.getNombre());
				}
				break;
			case 4:
				System.out.println("Pago por el curso " + curso1.getNombre() + "\n Precio a pagar: " + curso1.calcularDescuento(ninho1));
				break;
			case 5:
				System.out.println("Salimos de la app");
				break;
			default:
				System.out.println("opcion no valida");
				return;
			}

		} while (opcion != 5);
	}
}
