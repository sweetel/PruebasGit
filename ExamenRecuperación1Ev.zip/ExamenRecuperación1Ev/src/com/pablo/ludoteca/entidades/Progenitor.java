package com.pablo.ludoteca.entidades;

public class Progenitor extends Persona{

	private Ninho tipoNinho;

	public Progenitor(String nombre, Integer edad, char sexo) {
		super(nombre, edad, sexo);
	}

	public Ninho getTipoNinho() {
		return tipoNinho;
	}

	public void setTipoNinho(Ninho tipoNinho) {
		this.tipoNinho = tipoNinho;
	}
	
	
}
