package com.pablo.ludoteca.interfaces;

import java.util.Scanner;

import com.pablo.ludoteca.entidades.Curso;

public class MenuAltaCurso {

	public Curso mostarMenu(Scanner sc) {
		
		System.out.println("Digame la id del curso");
		Integer id = sc.nextInt();
		sc.nextLine();
		System.out.println("Digame el nombre del curso");
		String nombre = sc.nextLine();
		System.out.println("Digame el precio del curso");
		Double precio = sc.nextDouble();
		sc.nextLine();
		
		
		Curso curso1 = new Curso(id, nombre, precio);
		return curso1;
	}
}
