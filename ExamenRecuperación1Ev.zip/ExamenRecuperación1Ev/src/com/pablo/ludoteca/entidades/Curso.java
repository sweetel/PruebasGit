package com.pablo.ludoteca.entidades;

public class Curso {

	private Integer id;
	private String nombre;
	private Double precio;

	public Curso(Integer id, String nombre, Double precio) {
		this.id = id;
		this.nombre = nombre;
		this.precio = precio;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Double getPrecio() {
		return precio;
	}

	public void setPrecio(Double precio) {
		this.precio = precio;
	}

	public Double calcularDescuento(Ninho ninho) {
		
		Double descuento = null;
		if (ninho.getTieneDiscapacidad() == true) {
			if (ninho.getEdad() >= 1 && ninho.getEdad() <= 2) {
				descuento = this.getPrecio() * 0.8 * 0.7;
			} else if (ninho.getEdad() >= 3 && ninho.getEdad() <= 5) {
				descuento = this.getPrecio() * 0.9 * 0.7;
			} else if (ninho.getEdad() > 5) {
				descuento = this.getPrecio() * 0.7;
			}
		} 
		else {
			if (ninho.getEdad() >= 1 && ninho.getEdad() <= 2) {
				descuento = this.getPrecio() * 0.8;
			} else if (ninho.getEdad() >= 3 && ninho.getEdad() <= 5) {
				descuento = this.getPrecio() * 0.9;
			} else if (ninho.getEdad() > 5) {
				descuento = this.getPrecio();
			}
		} 
		
		return descuento;
	}
}
