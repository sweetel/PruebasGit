package com.pablo.ludoteca.interfaces;

import java.util.Scanner;

import com.pablo.ludoteca.entidades.Ninho;

public class MenuAltaNinho {

	public Ninho mostrarMenu(Scanner sc) {

		Boolean tieneDiscapacidad = null;

		System.out.println("Digame el nombre del niño");
		String nombre = sc.nextLine();
		System.out.println("Digame la edad del niño");
		Integer edad = sc.nextInt();
		System.out.println("Digame el sexo del niño");
		char sexo = sc.next().charAt(0);
		sc.nextLine();
		System.out.println("Tiene alguna discapacidad? [S/N]");
		String discapacidad = sc.nextLine();
		if (discapacidad.equalsIgnoreCase("s")) {
			tieneDiscapacidad = true;
		} else if (discapacidad.equalsIgnoreCase("n")) {
			tieneDiscapacidad = false;
		}		
		
		Ninho ninho1 = new Ninho(nombre, edad, sexo, tieneDiscapacidad);
		return ninho1;
		
	}
}
