package com.pablo.ludoteca.interfaces;

import java.util.Scanner;

import com.pablo.ludoteca.entidades.Progenitor;

public class MenuAltaProgenitor {

	public Progenitor mostrarMenu(Scanner sc) {

		System.out.println("Digame el nombre del progenitor");
		String nombre = sc.nextLine();
		System.out.println("Digame la edad del progenitor");
		Integer edad = sc.nextInt();
		sc.nextLine();
		System.out.println("Digame el sexo del progenitor [H/M]");
		char sexo = sc.next().charAt(0);

		Progenitor progenitor1 = new Progenitor(nombre, edad, sexo);

		return progenitor1;
	}
}
