package com.pablo.ludoteca.principal;

import com.pablo.ludoteca.interfaces.MenuPrincipal;

public class Principal {

	public static void main(String[] args) {
		
		MenuPrincipal mp = new MenuPrincipal();
		mp.mostrarMenu();

	}

}
